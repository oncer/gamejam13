#pragma once

#include "sdk.h"
#include "Game.h"

extern Game* g_game;