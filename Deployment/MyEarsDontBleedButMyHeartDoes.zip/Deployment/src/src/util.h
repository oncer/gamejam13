#include "sdk.h"
#include <fstream>
#include <cerrno>

std::string get_file_contents(const char *filename);